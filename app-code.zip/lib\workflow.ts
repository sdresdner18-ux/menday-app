import { WorkflowStage, WorkflowStageType } from "@prisma/client";
import { prisma } from "./prisma";

export type { WorkflowStage, WorkflowStageType };

export interface SerializedWorkflowStage {
  id: string;
  slug: string;
  label: string;
  position: number;
  stageType: WorkflowStageType;
  color: string;
}

export const LEGACY_STATUS_TO_SLUG: Record<string, string> = {
  New: "new",
  NeedsClarification: "needs-clarification",
  WaitingForFiles: "waiting-for-files",
  InProgress: "in-progress",
  Printing: "in-progress",
  Packed: "packed",
  AwaitingPayment: "awaiting-payment",
  Completed: "completed",
};

export const DEFAULT_WORKFLOW_STAGES: Omit<
  WorkflowStage,
  "id" | "createdAt" | "updatedAt"
>[] = [
  {
    slug: "new",
    label: "New",
    position: 0,
    stageType: "Normal",
    color: "zinc",
  },
  {
    slug: "needs-clarification",
    label: "Needs Clarification",
    position: 1,
    stageType: "Normal",
    color: "amber",
  },
  {
    slug: "waiting-for-files",
    label: "Waiting for Files",
    position: 2,
    stageType: "Normal",
    color: "yellow",
  },
  {
    slug: "in-progress",
    label: "In Progress",
    position: 3,
    stageType: "Normal",
    color: "blue",
  },
  {
    slug: "packed",
    label: "Packed",
    position: 4,
    stageType: "Normal",
    color: "teal",
  },
  {
    slug: "awaiting-payment",
    label: "Awaiting Payment",
    position: 5,
    stageType: "Payment",
    color: "orange",
  },
  {
    slug: "completed",
    label: "Completed",
    position: 6,
    stageType: "Archive",
    color: "emerald",
  },
];

export const STAGE_COLOR_PALETTE = [
  "zinc",
  "amber",
  "yellow",
  "blue",
  "teal",
  "orange",
  "emerald",
  "violet",
  "rose",
  "cyan",
  "indigo",
  "pink",
] as const;

export function serializeWorkflowStage(
  stage: WorkflowStage
): SerializedWorkflowStage {
  return {
    id: stage.id,
    slug: stage.slug,
    label: stage.label,
    position: stage.position,
    stageType: stage.stageType,
    color: stage.color,
  };
}

export function slugifyStageLabel(label: string): string {
  return label
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 48) || "stage";
}

export async function ensureWorkflowStages(): Promise<SerializedWorkflowStage[]> {
  const count = await prisma.workflowStage.count();
  if (count === 0) {
    await prisma.workflowStage.createMany({
      data: DEFAULT_WORKFLOW_STAGES,
    });
  }
  return getWorkflowStages();
}

export async function getWorkflowStages(): Promise<SerializedWorkflowStage[]> {
  const stages = await prisma.workflowStage.findMany({
    orderBy: { position: "asc" },
  });
  return stages.map(serializeWorkflowStage);
}

export function getStageBySlug(
  stages: SerializedWorkflowStage[],
  slug: string
): SerializedWorkflowStage | undefined {
  return stages.find((s) => s.slug === slug);
}

export function getStageLabel(
  stages: SerializedWorkflowStage[],
  slug: string
): string {
  return getStageBySlug(stages, slug)?.label ?? slug;
}

export function getArchiveStage(
  stages: SerializedWorkflowStage[]
): SerializedWorkflowStage {
  return (
    stages.find((s) => s.stageType === "Archive") ??
    stages[stages.length - 1]
  );
}

export function getPaymentStage(
  stages: SerializedWorkflowStage[]
): SerializedWorkflowStage | undefined {
  return stages.find((s) => s.stageType === "Payment");
}

export function getDefaultStage(
  stages: SerializedWorkflowStage[]
): SerializedWorkflowStage {
  return (
    stages.find((s) => s.slug === "new") ??
    stages[0] ?? {
      id: "fallback-new",
      slug: "new",
      label: "New",
      position: 0,
      stageType: "Normal",
      color: "zinc",
    }
  );
}

/** Stages shown as active columns on the production board (excludes archive). */
export function getActiveBoardStages(
  stages: SerializedWorkflowStage[]
): SerializedWorkflowStage[] {
  return stages.filter((s) => s.stageType !== "Archive");
}

/** All board columns including the archive drop zone. */
export function getBoardColumnStages(
  stages: SerializedWorkflowStage[]
): SerializedWorkflowStage[] {
  return [...stages].sort((a, b) => a.position - b.position);
}

/** Stages available when creating a new order. */
export function getCreateOrderStages(
  stages: SerializedWorkflowStage[]
): SerializedWorkflowStage[] {
  return stages.filter(
    (s) =>
      s.stageType === "Normal" &&
      s.slug !== getArchiveStage(stages).slug &&
      s.slug !== getPaymentStage(stages)?.slug
  );
}

export function normalizeStatusSlug(
  status: string,
  stages: SerializedWorkflowStage[]
): string {
  if (stages.some((s) => s.slug === status)) return status;
  const legacy = LEGACY_STATUS_TO_SLUG[status];
  if (legacy && stages.some((s) => s.slug === legacy)) return legacy;
  return getDefaultStage(stages).slug;
}

export const STAGE_COLOR_HEX: Record<string, string> = {
  zinc: "#71717a",
  amber: "#f59e0b",
  yellow: "#eab308",
  blue: "#3b82f6",
  teal: "#14b8a6",
  orange: "#f97316",
  emerald: "#10b981",
  violet: "#8b5cf6",
  rose: "#f43f5e",
  cyan: "#06b6d4",
  indigo: "#6366f1",
  pink: "#ec4899",
};

export function getStageColorHex(color: string): string {
  return STAGE_COLOR_HEX[color] ?? STAGE_COLOR_HEX.zinc;
}

export function getStageDotStyle(color: string): { backgroundColor: string } {
  return { backgroundColor: getStageColorHex(color) };
}

export function getStageBadgeStyle(color: string): {
  backgroundColor: string;
  color: string;
  borderColor: string;
} {
  const hex = getStageColorHex(color);
  return {
    backgroundColor: `color-mix(in srgb, ${hex} 14%, transparent)`,
    color: hex,
    borderColor: `color-mix(in srgb, ${hex} 30%, transparent)`,
  };
}

export function getStageColumnStyle(color: string): {
  borderTopColor: string;
} {
  return { borderTopColor: getStageColorHex(color) };
}
